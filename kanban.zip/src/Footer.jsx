import "./Footer.css"


function Footer(){
    return(
        <div className="grid-footer">
            <div className="footer">
                Footer new
            </div>
        </div>
    );
}

export default Footer;
